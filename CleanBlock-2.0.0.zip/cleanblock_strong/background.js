const DEFAULTS = {
  enabled: true,
  nuisance: true,
  blockedCount: 0,
  allowlist: []
};

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(DEFAULTS);
  await chrome.storage.local.set({
    enabled: current.enabled ?? true,
    nuisance: current.nuisance ?? true,
    blockedCount: current.blockedCount ?? 0,
    allowlist: current.allowlist ?? []
  });
  await applyRules(current.enabled ?? true, current.nuisance ?? true);
});

async function applyRules(enabled, nuisance) {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: [
      ...(enabled ? ["base_rules"] : []),
      ...(enabled && nuisance ? ["nuisance_rules"] : [])
    ],
    disableRulesetIds: [
      ...(enabled ? [] : ["base_rules", "nuisance_rules"]),
      ...(enabled && nuisance ? [] : ["nuisance_rules"])
    ]
  });
}

chrome.storage.onChanged.addListener(async (changes) => {
  if (changes.enabled || changes.nuisance) {
    const data = await chrome.storage.local.get({enabled:true,nuisance:true});
    await applyRules(data.enabled, data.nuisance);
  }
});

chrome.declarativeNetRequest.onRuleMatchedDebug?.addListener(async () => {
  const {blockedCount = 0} = await chrome.storage.local.get("blockedCount");
  await chrome.storage.local.set({blockedCount: blockedCount + 1});
});