const enabledBtn=document.getElementById("enabled"), label=enabledBtn.querySelector(".label"), count=document.getElementById("count"), nuisance=document.getElementById("nuisance"), reset=document.getElementById("reset"), open=document.getElementById("open");
async function refresh(){const d=await chrome.storage.local.get({enabled:true,nuisance:true,blockedCount:0}); enabledBtn.classList.toggle("on",d.enabled); label.textContent=d.enabled?"Protection is on":"Protection is off"; count.textContent=d.blockedCount.toLocaleString(); nuisance.checked=d.nuisance;}
enabledBtn.onclick=async()=>{const {enabled=true}=await chrome.storage.local.get("enabled"); await chrome.storage.local.set({enabled:!enabled}); refresh();};
nuisance.onchange=()=>chrome.storage.local.set({nuisance:nuisance.checked});
reset.onclick=()=>chrome.storage.local.set({blockedCount:0}).then(refresh);
open.onclick=()=>chrome.tabs.create({url:"chrome://extensions"});
refresh();