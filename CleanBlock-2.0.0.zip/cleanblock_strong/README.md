# CleanBlock

CleanBlock is a small Manifest V3 content blocker focused on common advertising, tracking, popup, and nuisance requests.

## What it does
- Uses Chrome's `declarativeNetRequest` API.
- Includes a curated starter set of advertising/tracking domains.
- Optional nuisance rules for common ad URL paths and popup-related requests.
- Local enable/disable control.
- Local blocked-request counter.
- No analytics, accounts, remote code, or external JavaScript dependencies.

## Install
1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Select **Load unpacked**.
4. Choose this repository's folder (the folder containing `manifest.json`).

## Important
This is intentionally a curated blocker, not a promise to block every advertisement. Large filter-list projects require continual maintenance and careful compatibility testing. Overly broad rules can break legitimate websites, so CleanBlock favors targeted network rules.

## License
MIT
